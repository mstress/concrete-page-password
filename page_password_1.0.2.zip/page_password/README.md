# Page Password

A professional password protection add-on for Concrete CMS 9.x.

## Features

- **Simple attribute-based protection** — Set a password via the page attribute panel
- **Parent inheritance** — Protecting a page automatically protects all its descendants
- **Session persistence** — Users stay unlocked for the duration of their session
- **Dashboard management** — View and manage all protected pages in one place
- **Secure design** — Supports both plain text and bcrypt-hashed passwords
- **Minimal UI** — Dark, professional password entry screen

## Installation

1. Copy the `page_password` folder to your Concrete CMS `packages/` directory
2. Go to Dashboard → Extend Concrete
3. Click "Install" on Page Password

## Usage

### Protecting a Page

1. Navigate to the page you want to protect
2. Click the page menu → Properties (or use the Sitemap)
3. Find the "Page Password" attribute
4. Enter a password and save

All child pages under the protected page will also require the password. Unlocking the parent unlocks the entire branch for that session.

### Using Hashed Passwords

For additional security, you can store bcrypt-hashed passwords instead of plain text:

```php
// Generate a hash
$hash = password_hash('your-password', PASSWORD_DEFAULT);
// Then paste the hash as the attribute value
```

### Managing Protected Pages

Go to Dashboard → Page Password to see all protected pages and quickly remove protection.

## Requirements

- Concrete CMS 9.0.0 or higher
- PHP 8.0 or higher

## License

MIT License

---

Built with restraint.
