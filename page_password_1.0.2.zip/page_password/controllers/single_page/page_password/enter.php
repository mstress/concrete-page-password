<?php

namespace Concrete\Package\PagePassword\Controller\SinglePage\PagePassword;

defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Page\Controller\PageController;
use Concrete\Core\Encryption\PasswordHasher;

class Enter extends PageController
{
    public function view()
    {
        $target = $this->request->query->get('target', '/');
        $this->set('targetPath', $target);
        $this->set('error', null);
        
        // Get the target page to check if it actually requires a password
        $targetPage = \Page::getByPath($target);
        
        if (!$targetPage || $targetPage->isError()) {
            return $this->redirect('/');
        }
        
        $password = $targetPage->getAttribute('page_password');
        
        if (!$password) {
            return $this->redirect($target);
        }
        
        $this->set('pageName', $targetPage->getCollectionName());
    }

    public function submit()
    {
        $target = $this->request->request->get('target', '/');
        $submittedPassword = $this->request->request->get('password', '');
        
        // Validate token
        $token = $this->app->make('token');
        if (!$token->validate('page_password_submit')) {
            $this->set('error', t('Security token expired. Please try again.'));
            $this->set('targetPath', $target);
            return;
        }
        
        // Get target page
        $targetPage = \Page::getByPath($target);
        
        if (!$targetPage || $targetPage->isError()) {
            return $this->redirect('/');
        }
        
        $storedPassword = $targetPage->getAttribute('page_password');
        
        if (!$storedPassword) {
            return $this->redirect($target);
        }
        
        // Check password - support both hashed and plain text
        $isValid = false;
        
        // Try hashed comparison first (bcrypt format starts with $2)
        if (strpos($storedPassword, '$2') === 0) {
            $isValid = password_verify($submittedPassword, $storedPassword);
        } else {
            // Plain text comparison (simple use case)
            $isValid = hash_equals($storedPassword, $submittedPassword);
        }
        
        if (!$isValid) {
            $this->set('error', t('Incorrect password.'));
            $this->set('targetPath', $target);
            $this->set('pageName', $targetPage->getCollectionName());
            return;
        }
        
        // Store unlock in session
        $session = $this->app->make('session');
        $unlockedPages = $session->get('page_password_unlocked', []);
        $unlockedPages[] = $targetPage->getCollectionID();
        $session->set('page_password_unlocked', array_unique($unlockedPages));
        
        // Redirect to target
        return $this->redirect($target);
    }
}
