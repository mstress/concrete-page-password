<?php

namespace Concrete\Package\PagePassword\Controller\SinglePage\Dashboard;

defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Page\Controller\DashboardPageController;
use Concrete\Core\Page\PageList;

class PagePassword extends DashboardPageController
{
    public function view()
    {
        $list = new PageList();
        $list->filterByAttribute('page_password', '', '!=');
        $list->sortByName();
        
        $pages = $list->getResults();
        
        $this->set('protectedPages', $pages);
        $this->set('pageTitle', t('Protected Pages'));
    }

    public function clear_page($cID = null)
    {
        if (!$this->token->validate('clear_page_password')) {
            $this->error->add(t('Invalid security token.'));
            return $this->view();
        }

        if (!$cID) {
            $this->error->add(t('No page specified.'));
            return $this->view();
        }

        $page = \Page::getByID((int)$cID);
        
        if (!$page || $page->isError()) {
            $this->error->add(t('Page not found.'));
            return $this->view();
        }

        $page->clearAttribute('page_password');
        
        $this->flash('success', t('Password protection removed from "%s".', $page->getCollectionName()));
        
        return $this->redirect('/dashboard/page_password');
    }
}
