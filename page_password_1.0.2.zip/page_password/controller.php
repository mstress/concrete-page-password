<?php

namespace Concrete\Package\PagePassword;

defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Attribute\Category\CategoryService;
use Concrete\Core\Attribute\TypeFactory;
use Concrete\Core\Http\ServerInterface;
use Concrete\Core\Package\Package;
use Concrete\Core\Page\Single as SinglePage;
use Concrete\Package\PagePassword\Http\Middleware\PagePasswordMiddleware;

/**
 * Page Password Protection
 * 
 * Adds password protection capability to any page via a simple page attribute.
 * Professional, secure, session-persistent.
 */
class Controller extends Package
{
    protected $pkgHandle = 'page_password';
    protected $appVersionRequired = '9.0.0';
    protected $pkgVersion = '1.0.2';

    protected $pkgAutoloaderRegistries = [
        'src' => '\Concrete\Package\PagePassword',
    ];

    public function getPackageDescription(): string
    {
        return t('Password protect any page with a simple attribute. Session-persistent, secure, minimal UI.');
    }

    public function getPackageName(): string
    {
        return t('Page Password');
    }

    public function install()
    {
        $pkg = parent::install();
        
        $this->installPageAttribute($pkg);
        $this->installSinglePages($pkg);
        
        return $pkg;
    }

    public function upgrade()
    {
        parent::upgrade();
        
        $pkg = $this->getPackageEntity();
        $this->installPageAttribute($pkg);
        $this->installSinglePages($pkg);
    }

    public function uninstall()
    {
        parent::uninstall();
    }

    public function on_start(): void
    {
        // Register middleware for password checking
        $this->app->extend(ServerInterface::class, function (ServerInterface $server) {
            $server->addMiddleware($this->app->make(PagePasswordMiddleware::class));
            return $server;
        });
    }

    private function installPageAttribute($pkg): void
    {
        $service = $this->app->make(CategoryService::class);
        $categoryEntity = $service->getByHandle('collection');
        $category = $categoryEntity->getController();
        
        // Check if attribute key already exists
        $key = $category->getAttributeKeyByHandle('page_password');
        
        if (!$key) {
            $factory = $this->app->make(TypeFactory::class);
            $type = $factory->getByHandle('text');
            
            $key = $category->add(
                $type,
                [
                    'akHandle' => 'page_password',
                    'akName' => t('Page Password'),
                    'akIsSearchable' => false,
                    'akIsSearchableIndexed' => false,
                ],
                $pkg
            );
        }
    }

    private function installSinglePages($pkg): void
    {
        // Dashboard page
        $dashboard = \Page::getByPath('/dashboard/page_password');
        if (!$dashboard || $dashboard->isError()) {
            $dashboard = SinglePage::add('/dashboard/page_password', $pkg);
            $dashboard->updateCollectionName(t('Page Password'));
            $dashboard->setAttribute('meta_description', t('Manage password-protected pages'));
        }
        
        // Frontend password entry page
        $entry = \Page::getByPath('/page_password/enter');
        if (!$entry || $entry->isError()) {
            $entry = SinglePage::add('/page_password/enter', $pkg);
            $entry->updateCollectionName(t('Enter Password'));
            $entry->setAttribute('exclude_nav', true);
            $entry->setAttribute('exclude_search_index', true);
        }
    }
}
