<?php

defined('C5_EXECUTE') or die('Access Denied.');

/** @var string $targetPath */
/** @var string|null $pageName */
/** @var string|null $error */

$token = Core::make('token');
$form = Core::make('helper/form');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= t('Protected Page') ?></title>
    <style>
        *, *::before, *::after {
            box-sizing: border-box;
        }
        
        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #0a0a0a;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .password-container {
            width: 100%;
            max-width: 380px;
        }
        
        .password-header {
            margin-bottom: 40px;
        }
        
        .password-label {
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: #666;
            margin-bottom: 8px;
        }
        
        .password-title {
            font-size: 20px;
            font-weight: 500;
            color: #fff;
            margin: 0;
            line-height: 1.3;
            word-break: break-word;
        }
        
        .password-form {
            margin: 0;
        }
        
        .password-input {
            width: 100%;
            padding: 16px 18px;
            font-size: 16px;
            font-family: inherit;
            background: #1a1a1a;
            border: 1px solid #333;
            color: #fff;
            border-radius: 4px;
            outline: none;
            transition: border-color 0.15s ease;
        }
        
        .password-input:focus {
            border-color: #555;
        }
        
        .password-input::placeholder {
            color: #555;
        }
        
        .password-submit {
            width: 100%;
            padding: 16px 20px;
            margin-top: 12px;
            font-size: 14px;
            font-weight: 600;
            font-family: inherit;
            letter-spacing: 0.3px;
            background: #fff;
            color: #000;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.15s ease;
        }
        
        .password-submit:hover {
            background: #e0e0e0;
        }
        
        .password-submit:active {
            background: #ccc;
        }
        
        .password-error {
            margin-top: 16px;
            padding: 14px 16px;
            font-size: 13px;
            background: rgba(200, 50, 50, 0.15);
            border: 1px solid rgba(200, 50, 50, 0.3);
            border-radius: 4px;
            color: #e57373;
        }
        
        .password-back {
            display: block;
            margin-top: 32px;
            font-size: 13px;
            color: #555;
            text-decoration: none;
            text-align: center;
        }
        
        .password-back:hover {
            color: #888;
        }
    </style>
</head>
<body>
    <div class="password-container">
        <div class="password-header">
            <div class="password-label"><?= t('Protected') ?></div>
            <h1 class="password-title"><?= isset($pageName) ? h($pageName) : t('This page') ?></h1>
        </div>
        
        <form class="password-form" method="post" action="<?= URL::to('/page_password/enter', 'submit') ?>">
            <?= $token->output('page_password_submit') ?>
            <input type="hidden" name="target" value="<?= h($targetPath) ?>">
            
            <input 
                type="password" 
                name="password" 
                class="password-input"
                placeholder="<?= t('Password') ?>"
                autocomplete="current-password"
                autofocus
                required
            >
            
            <button type="submit" class="password-submit">
                <?= t('Continue') ?>
            </button>
            
            <?php if (!empty($error)): ?>
            <div class="password-error">
                <?= h($error) ?>
            </div>
            <?php endif; ?>
        </form>
        
        <a href="/" class="password-back"><?= t('Return to site') ?></a>
    </div>
</body>
</html>
<?php exit; ?>
