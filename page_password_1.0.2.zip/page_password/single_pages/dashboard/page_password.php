<?php

defined('C5_EXECUTE') or die('Access Denied.');

/** @var Concrete\Core\Page\Page[] $protectedPages */
/** @var Concrete\Core\Validation\CSRF\Token $token */
/** @var Concrete\Core\Form\Service\Form $form */

$form = Core::make('helper/form');
$token = Core::make('token');
?>

<div class="ccm-dashboard-header-buttons">
    <a href="<?= URL::to('/dashboard/sitemap/full') ?>" class="btn btn-secondary">
        <?= t('Sitemap') ?>
    </a>
</div>

<?php if (empty($protectedPages)): ?>

<div class="ccm-dashboard-content-full">
    <div style="padding: 60px 40px; text-align: center;">
        <p style="font-size: 15px; color: #666; margin: 0 0 20px 0;">
            <?= t('No pages are currently password protected.') ?>
        </p>
        <p style="font-size: 13px; color: #999; margin: 0;">
            <?= t('To protect a page, edit the page and set the "Page Password" attribute.') ?>
        </p>
    </div>
</div>

<?php else: ?>

<table class="ccm-search-results-table">
    <thead>
        <tr>
            <th style="width: 50%;"><?= t('Page') ?></th>
            <th style="width: 30%;"><?= t('Path') ?></th>
            <th style="width: 20%; text-align: right;"><?= t('Actions') ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($protectedPages as $page): ?>
        <tr>
            <td>
                <strong><?= h($page->getCollectionName()) ?></strong>
            </td>
            <td>
                <code style="font-size: 12px; color: #666;"><?= h($page->getCollectionPath()) ?></code>
            </td>
            <td style="text-align: right;">
                <a href="<?= URL::to('/dashboard/sitemap/full', 'view', $page->getCollectionID()) ?>" 
                   class="btn btn-sm btn-secondary">
                    <?= t('Edit') ?>
                </a>
                <a href="<?= URL::to('/dashboard/page_password', 'clear_page', $page->getCollectionID()) ?>?<?= $token->getParameter('clear_page_password') ?>" 
                   class="btn btn-sm btn-danger"
                   onclick="return confirm('<?= t('Remove password protection from this page?') ?>');">
                    <?= t('Remove') ?>
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php endif; ?>

<style>
.ccm-search-results-table {
    width: 100%;
    border-collapse: collapse;
}
.ccm-search-results-table th {
    background: #f5f5f5;
    border-bottom: 2px solid #ddd;
    padding: 12px 16px;
    text-align: left;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #333;
}
.ccm-search-results-table td {
    padding: 14px 16px;
    border-bottom: 1px solid #eee;
    vertical-align: middle;
}
.ccm-search-results-table tbody tr:hover {
    background: #fafafa;
}
.btn-sm {
    padding: 4px 10px;
    font-size: 12px;
}
</style>
