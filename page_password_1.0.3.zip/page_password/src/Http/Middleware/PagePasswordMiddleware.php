<?php

namespace Concrete\Package\PagePassword\Http\Middleware;

defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Http\Middleware\DelegateInterface;
use Concrete\Core\Http\Middleware\MiddlewareInterface;
use Concrete\Core\Application\ApplicationAwareInterface;
use Concrete\Core\Application\ApplicationAwareTrait;
use Concrete\Core\User\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Page;

class PagePasswordMiddleware implements MiddlewareInterface, ApplicationAwareInterface
{
    use ApplicationAwareTrait;

    /**
     * Process the request and check for password protection
     */
    public function process(Request $request, DelegateInterface $frame)
    {
        $path = $request->getPathInfo();
        
        // Skip certain paths
        if ($this->shouldSkip($path)) {
            return $frame->next($request);
        }
        
        // Get the page for this request
        $page = Page::getByPath($path);
        
        if (!$page || $page->isError()) {
            return $frame->next($request);
        }
        
        // Skip admin pages
        if ($page->isAdminArea()) {
            return $frame->next($request);
        }
        
        // Check this page and all ancestors for password protection
        $protectedPage = $this->findProtectedPage($page);
        
        if (!$protectedPage) {
            return $frame->next($request);
        }
        
        // Bypass for logged-in users who can edit the protected page
        if ($this->userCanEdit($protectedPage)) {
            return $frame->next($request);
        }
        
        // Check session for unlock (keyed by the protected page's ID)
        $session = $this->app->make('session');
        $unlockedPages = $session->get('page_password_unlocked', []);
        
        if (in_array($protectedPage->getCollectionID(), $unlockedPages)) {
            return $frame->next($request);
        }
        
        // Redirect to password entry — target is the protected ancestor, not the requested page
        $url = $this->app->make('url/resolver/path');
        $redirectUrl = $url->resolve(['/page_password/enter']) . '?target=' . urlencode($protectedPage->getCollectionPath());
        
        return new RedirectResponse($redirectUrl);
    }

    /**
     * Check if current user can edit the given page
     */
    private function userCanEdit(Page $page): bool
    {
        $user = $this->app->make(User::class);
        
        if (!$user->isRegistered()) {
            return false;
        }
        
        $permissions = new \Permissions($page);
        
        return $permissions->canEditPageContents();
    }

    /**
     * Walk up the page tree to find the nearest password-protected page
     * Returns the protected page, or null if none found
     */
    private function findProtectedPage(Page $page): ?Page
    {
        $current = $page;
        
        while ($current && !$current->isError()) {
            $password = $current->getAttribute('page_password');
            
            if ($password) {
                return $current;
            }
            
            // Move to parent
            $parentID = $current->getCollectionParentID();
            
            if (!$parentID || $parentID == $current->getCollectionID()) {
                break;
            }
            
            $current = Page::getByID($parentID);
        }
        
        return null;
    }

    /**
     * Paths that should never be checked for passwords
     */
    private function shouldSkip(string $path): bool
    {
        $skipPaths = [
            '/page_password/enter',
            '/login',
            '/ccm',
            '/dashboard',
        ];
        
        foreach ($skipPaths as $skip) {
            if (strpos($path, $skip) === 0) {
                return true;
            }
        }
        
        return false;
    }
}
